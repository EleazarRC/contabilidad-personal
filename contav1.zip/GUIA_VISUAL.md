# 🎨 Guía Visual de la Interfaz

## Navegación Principal

```
┌─────────────────────────────────────────────────────────────────┐
│  💰 Contabilidad Personal                                       │
│                                                                 │
│  Dashboard | Transacciones | Categorías | Mensual | Anual      │
└─────────────────────────────────────────────────────────────────┘
```

**Barra de Navegación:**
- Fondo: Gradiente morado/violeta
- Links: Blanco con subrayado al hacer hover
- Siempre visible en todas las páginas

---

## 📊 Dashboard (Página Principal)

### Tarjetas de Resumen
```
┌────────────────┐  ┌────────────────┐  ┌────────────────┐
│ Total Ingresos │  │  Total Gastos  │  │    Balance     │
│                │  │                │  │                │
│   € 3,500.00   │  │   € 1,845.75   │  │  € 1,654.25    │
│     (verde)    │  │     (rojo)     │  │   (morado)     │
└────────────────┘  └────────────────┘  └────────────────┘
```

### Gráficos Circulares
```
┌─────────────────────────┐  ┌─────────────────────────┐
│ Ingresos por Categoría  │  │  Gastos por Categoría   │
│                         │  │                         │
│      [Gráfico Pie]      │  │      [Gráfico Pie]      │
│                         │  │                         │
│  Leyenda con colores    │  │  Leyenda con colores    │
└─────────────────────────┘  └─────────────────────────┘
```

### Transacciones Recientes
```
┌───────────────────────────────────────────────────────────┐
│  Fecha      │ Descripción      │ Categoría  │ Tipo │ Monto│
├───────────────────────────────────────────────────────────┤
│ 07/02/2026  │ Salario mensual  │ [Salario]  │ ⬆️ │ +€2,500│
│ 05/02/2026  │ Compra mercado   │ [Aliment.] │ ⬇️ │ -€85.50│
│ 03/02/2026  │ Netflix          │ [Entrete.] │ ⬇️ │ -€15.99│
└───────────────────────────────────────────────────────────┘
```

---

## 💳 Transacciones

### Botón de Acción
```
┌─────────────────────────────────────────────────────────┐
│  Transacciones              [+ Nueva Transacción] 🔵    │
└─────────────────────────────────────────────────────────┘
```

### Formulario (aparece al hacer clic)
```
┌─────────────────────────────────────────────────────────┐
│  Nueva Transacción                                      │
├─────────────────────────────────────────────────────────┤
│  Tipo: [Gasto ▼]              Fecha: [07/02/2026]      │
│                                                         │
│  Descripción: [____________________________]            │
│                                                         │
│  Monto: [_______]             Categoría: [Aliment. ▼]  │
│                                                         │
│  [Crear] [Cancelar]                                     │
└─────────────────────────────────────────────────────────┘
```

### Filtros
```
┌─────────────────────────────────────────────────────────┐
│  Mes: [Febrero ▼]  Año: [2026 ▼]  Tipo: [Todos ▼]     │
│  Categoría: [Todas ▼]                                  │
└─────────────────────────────────────────────────────────┘
```

### Lista de Transacciones
```
┌────────────────────────────────────────────────────────────────┐
│  Fecha      │ Descripción      │ Categoría  │ Tipo    │ Monto │ Acciones│
├────────────────────────────────────────────────────────────────┤
│ 07/02/2026  │ Salario mensual  │ [Salario]  │ ingreso │ +€2,500│ [📝][🗑️]│
│ 05/02/2026  │ Compra mercado   │ [Aliment.] │ gasto   │ -€85.50│ [📝][🗑️]│
│ 03/02/2026  │ Netflix          │ [Entrete.] │ gasto   │ -€15.99│ [📝][🗑️]│
│ 01/02/2026  │ Alquiler         │ [Vivienda] │ gasto   │ -€800  │ [📝][🗑️]│
└────────────────────────────────────────────────────────────────┘
```

**Características:**
- Categorías con badges de color
- Tipos con badges (verde para ingresos, rojo para gastos)
- Botones de Editar y Eliminar por fila
- Hover sobre filas cambia el fondo

---

## 🏷️ Categorías

### Vista Dividida
```
┌─────────────────────────────────────────────────────────────┐
│  Categorías                        [+ Nueva Categoría] 🔵   │
└─────────────────────────────────────────────────────────────┘

┌──────────────────────────┐  ┌──────────────────────────┐
│ Categorías de Ingresos   │  │  Categorías de Gastos    │
│ (3)                      │  │  (9)                     │
├──────────────────────────┤  ├──────────────────────────┤
│ [🟢] Salario             │  │ [🔴] Alimentación        │
│      [📝 Editar][🗑️]     │  │      [📝 Editar][🗑️]     │
│                          │  │                          │
│ [🟢] Inversiones         │  │ [🔴] Transporte          │
│      [📝 Editar][🗑️]     │  │      [📝 Editar][🗑️]     │
│                          │  │                          │
│ [🟢] Otros Ingresos      │  │ [🔴] Vivienda            │
│      [📝 Editar][🗑️]     │  │      [📝 Editar][🗑️]     │
│                          │  │                          │
│                          │  │ [🔴] Servicios           │
│                          │  │      [📝 Editar][🗑️]     │
│                          │  │                          │
│                          │  │ [🔴] Entretenimiento     │
│                          │  │      [📝 Editar][🗑️]     │
│                          │  │                          │
│                          │  │ [🔴] Salud               │
│                          │  │      [📝 Editar][🗑️]     │
└──────────────────────────┘  └──────────────────────────┘
```

### Formulario de Categoría
```
┌─────────────────────────────────────────────────────────┐
│  Nueva Categoría                                        │
├─────────────────────────────────────────────────────────┤
│  Nombre: [____________________________]                 │
│                                                         │
│  Tipo: [Gasto ▼]                                       │
│                                                         │
│  Color: [🎨] [#F44336]                                 │
│         └─ selector visual de color                    │
│                                                         │
│  [Crear] [Cancelar]                                     │
└─────────────────────────────────────────────────────────┘
```

---

## 📅 Reporte Mensual

### Selector y Resumen
```
┌─────────────────────────────────────────────────────────┐
│  Mes: [Febrero ▼]    Año: [2026 ▼]                     │
└─────────────────────────────────────────────────────────┘

┌────────────────┐  ┌────────────────┐  ┌────────────────┐
│ Total Ingresos │  │  Total Gastos  │  │    Balance     │
│   Anual        │  │    Anual       │  │     Anual      │
│   € 3,500.00   │  │   € 1,845.75   │  │  € 1,654.25    │
└────────────────┘  └────────────────┘  └────────────────┘
```

### Gráficos de Distribución
```
┌─────────────────────────┐  ┌─────────────────────────┐
│ Distribución Ingresos   │  │ Distribución Gastos     │
│                         │  │                         │
│    [Gráfico Pie]        │  │    [Gráfico Pie]        │
│                         │  │                         │
│  Con porcentajes en     │  │  Con porcentajes en     │
│  tooltips               │  │  tooltips               │
└─────────────────────────┘  └─────────────────────────┘
```

### Detalle por Categoría
```
┌──────────────────────────────────────────────────────┐
│  Categoría       │  Tipo    │  Total    │  % Total   │
├──────────────────────────────────────────────────────┤
│  [Salario]       │  ingreso │ € 2,500   │   71.4%    │
│  [Inversiones]   │  ingreso │ € 1,000   │   28.6%    │
│  [Alimentación]  │  gasto   │ € 450.50  │   24.4%    │
│  [Transporte]    │  gasto   │ € 150.25  │    8.1%    │
│  [Vivienda]      │  gasto   │ € 800.00  │   43.3%    │
└──────────────────────────────────────────────────────┘
```

---

## 📆 Reporte Anual

### Selector y Resumen Anual
```
┌─────────────────────────────────────────────────────────┐
│  Año: [2026 ▼]                                          │
└─────────────────────────────────────────────────────────┘

┌────────────────┐  ┌────────────────┐  ┌────────────────┐
│ Total Ingresos │  │  Total Gastos  │  │    Balance     │
│   Anual        │  │    Anual       │  │     Anual      │
│  € 35,000.00   │  │  € 22,450.80   │  │  € 12,549.20   │
└────────────────┘  └────────────────┘  └────────────────┘
```

### Gráfico de Barras Comparativo
```
┌─────────────────────────────────────────────────────────┐
│  Ingresos vs Gastos por Mes                             │
│                                                         │
│   €                                                     │
│ 4000│                                                   │
│     │ ██      ██                                        │
│ 3000│ ██  ██  ██  ██  ██  ██                           │
│     │ ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  │
│ 2000│ ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  │
│     │ ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  │
│ 1000│ ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  │
│     └─────────────────────────────────────────────────  │
│      Ene Feb Mar Abr May Jun Jul Ago Sep Oct Nov Dic   │
│                                                         │
│      ■ Ingresos (verde)  ■ Gastos (rojo)               │
└─────────────────────────────────────────────────────────┘
```

### Gráfico de Línea - Evolución del Balance
```
┌─────────────────────────────────────────────────────────┐
│  Evolución del Balance Mensual                          │
│                                                         │
│   €                                                     │
│ 2000│        ●────●                                     │
│     │       /      \                                    │
│ 1500│      /        \     ●────●                        │
│     │     /          \   /      \                       │
│ 1000│    ●            ● ●        ●────●                 │
│     │   /                              \                │
│  500│  ●                                ●───●           │
│     └─────────────────────────────────────────────────  │
│      Ene Feb Mar Abr May Jun Jul Ago Sep Oct Nov Dic   │
└─────────────────────────────────────────────────────────┘
```

### Gráficos de Distribución Anual
```
┌─────────────────────────┐  ┌─────────────────────────┐
│ Distribución Anual      │  │ Distribución Anual      │
│ de Ingresos             │  │ de Gastos               │
│                         │  │                         │
│    [Gráfico Pie]        │  │    [Gráfico Pie]        │
│                         │  │                         │
│  Muestra acumulado      │  │  Muestra acumulado      │
│  de todo el año         │  │  de todo el año         │
└─────────────────────────┘  └─────────────────────────┘
```

### Tabla Resumen Mensual
```
┌──────────────────────────────────────────────────────┐
│  Mes  │  Ingresos  │   Gastos   │    Balance        │
├──────────────────────────────────────────────────────┤
│  Ene  │ € 3,000.00 │ € 1,950.30 │ € 1,049.70 ✅     │
│  Feb  │ € 3,500.00 │ € 1,845.75 │ € 1,654.25 ✅     │
│  Mar  │ € 2,800.00 │ € 2,100.50 │ €   699.50 ✅     │
│  Abr  │ € 3,000.00 │ € 3,200.00 │ €  -200.00 ❌     │
│  May  │ € 2,900.00 │ € 1,800.25 │ € 1,099.75 ✅     │
│  ...  │    ...     │    ...     │     ...           │
└──────────────────────────────────────────────────────┘
```

### Tabla Detalle por Categoría Anual
```
┌──────────────────────────────────────────────────────┐
│  Categoría       │  Tipo    │  Total Anual│  % Total │
├──────────────────────────────────────────────────────┤
│  [Salario]       │  ingreso │ € 30,000    │   85.7%  │
│  [Inversiones]   │  ingreso │ €  5,000    │   14.3%  │
│  [Alimentación]  │  gasto   │ €  5,400    │   24.0%  │
│  [Vivienda]      │  gasto   │ €  9,600    │   42.8%  │
│  [Transporte]    │  gasto   │ €  1,800    │    8.0%  │
│  [Servicios]     │  gasto   │ €  2,400    │   10.7%  │
│  ...             │  ...     │  ...        │   ...    │
└──────────────────────────────────────────────────────┘
```

---

## 🎨 Paleta de Colores

### Colores Principales
- **Primario**: `#667eea` → `#764ba2` (Gradiente morado)
- **Ingresos**: `#28a745` (Verde)
- **Gastos**: `#dc3545` (Rojo)
- **Balance Positivo**: `#667eea` (Morado)
- **Balance Negativo**: `#dc3545` (Rojo)

### Colores de Categorías Predeterminadas
**Ingresos:**
- Salario: `#4CAF50` (Verde claro)
- Inversiones: `#8BC34A` (Verde lima)
- Otros Ingresos: `#CDDC39` (Lima)

**Gastos:**
- Alimentación: `#F44336` (Rojo)
- Transporte: `#E91E63` (Rosa)
- Vivienda: `#9C27B0` (Morado)
- Servicios: `#673AB7` (Morado oscuro)
- Entretenimiento: `#3F51B5` (Azul índigo)
- Salud: `#2196F3` (Azul)
- Educación: `#03A9F4` (Azul claro)
- Ropa: `#00BCD4` (Cian)
- Otros Gastos: `#009688` (Verde azulado)

### Colores de Fondo
- Página: `#f5f5f5` (Gris muy claro)
- Tarjetas: `#ffffff` (Blanco)
- Hover: `#f8f9fa` (Gris claro)

---

## 📱 Responsive

### En Móviles (< 768px)
- La navegación se apila verticalmente
- Los gráficos ocupan todo el ancho
- Las tablas son scrolleables horizontalmente
- Los formularios de 2 columnas pasan a 1 columna
- Los filtros se apilan verticalmente

### Ejemplo Móvil
```
┌─────────────────┐
│ 💰 Contabilidad│
│    Personal    │
├─────────────────┤
│   Dashboard    │
│  Transacciones │
│   Categorías   │
│    Mensual     │
│     Anual      │
└─────────────────┘

┌─────────────────┐
│ Total Ingresos │
│   € 3,500.00   │
└─────────────────┘

┌─────────────────┐
│  Total Gastos  │
│   € 1,845.75   │
└─────────────────┘

┌─────────────────┐
│    Balance     │
│  € 1,654.25    │
└─────────────────┘
```

---

## 💡 Elementos Interactivos

### Botones
- **Hover**: Se elevan ligeramente con sombra
- **Click**: Efecto de presionado
- **Colores**: Siguen la paleta definida

### Formularios
- **Focus**: Borde morado en input activo
- **Validación**: Mensajes de error en rojo
- **Success**: Mensajes en verde

### Tablas
- **Hover**: Fila cambia a gris claro
- **Sorting**: No implementado (mejora futura)

### Gráficos
- **Hover**: Tooltips con información detallada
- **Click en leyenda**: Toggle de datasets (Chart.js)
- **Responsive**: Se adaptan al contenedor

---

## 🔔 Mensajes y Estados

### Loading
```
┌─────────────────────────────────────┐
│                                     │
│          Cargando...                │
│                                     │
└─────────────────────────────────────┘
```

### Error
```
┌─────────────────────────────────────┐
│ ❌ Error al cargar transacciones    │
└─────────────────────────────────────┘
```

### Success
```
┌─────────────────────────────────────┐
│ ✅ Transacción creada exitosamente  │
└─────────────────────────────────────┘
```

### Empty State
```
┌─────────────────────────────────────┐
│                                     │
│    No hay transacciones este mes    │
│   Comienza agregando una nueva      │
│                                     │
│     [+ Nueva Transacción]           │
│                                     │
└─────────────────────────────────────┘
```

---

## ⌨️ Atajos de Teclado (No implementados)

Mejoras futuras sugeridas:
- `Ctrl + N`: Nueva transacción
- `Ctrl + K`: Buscar transacción
- `Esc`: Cerrar formulario
- `Enter`: Guardar formulario
- `Tab`: Navegación entre campos

---

## 🖱️ Acciones del Usuario

### Crear Transacción
1. Click en "+ Nueva Transacción"
2. Se abre formulario inline
3. Completar campos
4. Click en "Crear"
5. Formulario se cierra
6. Lista se actualiza automáticamente

### Editar Transacción
1. Click en botón "Editar" de una fila
2. Formulario se llena con datos existentes
3. Modificar campos deseados
4. Click en "Actualizar"
5. Cambios se reflejan inmediatamente

### Eliminar Transacción
1. Click en botón "Eliminar" de una fila
2. Aparece confirmación del navegador
3. Click en "Aceptar"
4. Transacción desaparece de la lista

### Filtrar Transacciones
1. Cambiar cualquier filtro (mes, año, tipo, categoría)
2. La lista se actualiza automáticamente
3. No requiere botón "Aplicar"

---

Esta guía visual te ayudará a entender cómo está organizada la interfaz sin necesidad de ejecutar la aplicación. Todos los elementos están diseñados para ser intuitivos y fáciles de usar.
